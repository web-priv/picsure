"use strict";

/*global require module*/

var _ = require('underscore');
var Backbone = require('backbone');

var events = _.extend({}, Backbone.Events);

module.exports = events;

"use strict";

/*global require module*/

var $ = require('jquery');
var bootstrap = require('bootstrap');
var Backbone = require('backbone');
Backbone.$ = $;

var App = require('./app');
App.init();
